components {
  id: "Background1"
  component: "/Game Resources/Environment/Asset Pack/BgImages/Background1.sprite"
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
components {
  id: "bg1"
  component: "/Game Resources/Environment/Asset Pack/BgImages/bg1.script"
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
