components {
  id: "bg2"
  component: "/Game Resources/Environment/Asset Pack/BgImages/bg2.script"
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
components {
  id: "Background2"
  component: "/Game Resources/Environment/Asset Pack/BgImages/Background2.sprite"
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
