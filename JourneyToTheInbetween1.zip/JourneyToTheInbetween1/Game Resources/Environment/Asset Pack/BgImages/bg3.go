components {
  id: "Background3"
  component: "/Game Resources/Environment/Asset Pack/BgImages/Background3.sprite"
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
components {
  id: "bg3"
  component: "/Game Resources/Environment/Asset Pack/BgImages/bg3.script"
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
